function setup(){
  noCanvas();
createElement('h1', 'Conexões entre o campo e a cidade');
  
  createElement('h2','⮕ O que é o campo?');
  
createP('⮕ O campo está relacionado neste tema como a área rural de uma cidade, onde se ocorre a Agricultura, muito importante para o mercado e para a nossa vida na terra.');
  
createP('Atualmente, no trabalho do campo, é utilizado novas tecnologias que aprimoraram muito a produtividade dos plantados, o que rendeu e muito as colheitas e vendas para o mercado, de onde garantimos nosso alimento.');
  
createP('Mas, o assunto não é sobre nossa atual tecnologia, e sim o por que há conexão entre o campo e a cidade? Como sabemos, tanto a cidade quanto o campo precisam um do outro, eles se ajudam com recursos necessários. A cidade precisa do campo pela agricultura, que fornece o plantio de alimentos para o mercado, e o campo necessita da cidade para adquirir alimentos, e recursos que de vez em quando faltam em nossa moradia.');//início do corpo do assunto.
  
createP('No vídeo abaixo, explicarei mais sobre o assunto.');
createVideo('https://youtube.com/shorts/seAABu7ZOcc?si=y7F3XRcXtkACm-lH');//entrevista sobre o campo.
 createElement('h2','⮕Entendido, mas o que tem a ver com a cidade?');
  
createP('Na cidade, como sabemos, existem os mercados, e nos mercados são vendidos produtos de limpeza, de higiene, alimentos, e tudo o que usamos para nossa sobrevivência, mas da onde vem os demais alimentos? Obviamente boa parte do que utilizamos vem natturalmente do campo, onde praticam a mais essencial agricultura. E o que a cidade tem a ver? Simples, a cidade precisa obviamente do campo, por causa da agricultura, que pratica o plantio de alimentos essenciais para a fabricação de outros e derivados, ou seja, boa parte de nossos alimentos derivados como o queijo, necessitam de boa parte do que vem do campo, sem contar dos vegetais e das frutas que compramos no mercado, boa parte veio das áreas rurais.');//continuação do corpo do assunto.
  
createP('No vídeo abaixo, explicarei mais sobre o assunto.');
createVideo('https://youtu.be/kZnYzHfCQVA?si=62TtNbsfNw6Vagmq');//entrevista sobre a cidade.
  
  createElement('h2','E por fim,');
createP('Como citado, o campo faz parte da cidade, e a cidade faz parte do campo. Ambas precisam uma da outra para sua existência e funcionamento, e as duas áreas são essenciais para a nossa sobrevivência. Já pensou não ter aquele pão quentinho com queijo ou manteiga no café da manhã? Ou aquele bife acebolado com batatinhas fritas no almoço? E aquela maçã recebida após o lanche na escola? E você, caro morador rural, já pensou ficar sem café para tomar no café da manhã? Ou ficar sem o seu trigo para fazer seus bolos e pães? E imagina só ficar sem a sua erva para tomar aquele bom chimarrão? Pois é, tudo é fruto do campo e da cidade, aprenda a aproveitar e a admirar essa conexão incrível das duas áreas, e nunca esquecer da importância de cada uma delas.');//reflexão sobre o tema.
}